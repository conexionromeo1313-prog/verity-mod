package com.verity.client;

import com.verity.entity.VerityEntity;
import com.verity.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

/** Only ever touched from the client (through DistExecutor). */
public class ClientHooks {
    public static void openSetup() {
        Minecraft.getInstance().setScreen(new SetupScreen());
    }

    public static void onSpeak(int entityId, String text) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        Entity e = mc.level.getEntity(entityId);
        VerityEntity verity = e instanceof VerityEntity v ? v : null;
        int estimate = Mth.clamp(text.length() * 2, 30, 400);

        if (!ClientConfig.hasTts()) {
            if (verity != null) verity.talkFor(estimate);
            return;
        }
        float vol = mc.options.getSoundSourceVolume(SoundSource.MASTER) * mc.options.getSoundSourceVolume(SoundSource.VOICE);
        FishTts.speak(text, ClientConfig.fishKey, ClientConfig.voiceId, vol,
                ms -> mc.execute(() -> { if (verity != null) verity.talkFor((int) (ms / 50L)); }),
                code -> mc.execute(() -> {
                    if (mc.player != null)
                        mc.player.sendSystemMessage(Component.literal("[Verity TTS] error " + code));
                    if (verity != null) verity.talkFor(estimate);
                }));
    }

    /** Re-sends the saved Groq key to the server we just joined. */
    public static void sendSavedKey() {
        if (!ClientConfig.groqKey.isBlank())
            ModNetwork.CHANNEL.sendToServer(new ModNetwork.Setup(ClientConfig.groqKey, false));
    }
}
