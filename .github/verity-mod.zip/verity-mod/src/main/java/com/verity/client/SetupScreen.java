package com.verity.client;

import com.verity.network.ModNetwork;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

import java.util.List;

public class SetupScreen extends Screen {
    private EditBox groqBox, voiceBox, fishBox;

    public SetupScreen() {
        super(Component.literal("Verity"));
    }

    @Override
    protected void init() {
        ClientConfig.load();
        int w = Math.min(260, width - 40);
        int x = (width - w) / 2;
        int y = Math.max(8, height / 2 - 110);

        // y + 0..46 : warning panel (drawn in render)
        groqBox = new EditBox(font, x, y + 74, w, 20, Component.literal("Groq API key"));
        groqBox.setMaxLength(300);
        groqBox.setValue(ClientConfig.groqKey);
        groqBox.setHint(Component.literal("gsk_..."));
        addRenderableWidget(groqBox);

        voiceBox = new EditBox(font, x, y + 120, w, 20, Component.literal("Fish Audio voice id"));
        voiceBox.setMaxLength(100);
        voiceBox.setValue(ClientConfig.voiceId);
        voiceBox.setHint(Component.literal("ID de voz (opcional)"));
        addRenderableWidget(voiceBox);

        fishBox = new EditBox(font, x, y + 156, w, 20, Component.literal("Fish Audio API key"));
        fishBox.setMaxLength(300);
        fishBox.setValue(ClientConfig.fishKey);
        fishBox.setHint(Component.literal("API key de Fish Audio (para el TTS)"));
        addRenderableWidget(fishBox);

        addRenderableWidget(Button.builder(Component.literal("Aceptar"), b -> accept())
                .bounds(x, y + 186, w, 20).build());
    }

    private void accept() {
        ClientConfig.groqKey = groqBox.getValue().trim();
        ClientConfig.voiceId = voiceBox.getValue().trim();
        ClientConfig.fishKey = fishBox.getValue().trim();
        ClientConfig.save();
        ModNetwork.CHANNEL.sendToServer(new ModNetwork.Setup(ClientConfig.groqKey, true));
        onClose();
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        int w = Math.min(260, width - 40);
        int x = (width - w) / 2;
        int y = Math.max(8, height / 2 - 110);

        // warning panel
        g.fill(x - 4, y - 4, x + w + 4, y + 52, 0xCC000000);
        g.fill(x - 4, y - 4, x + w + 4, y - 3, 0xFFEADE19);
        g.drawCenteredString(font, "ADVERTENCIA", width / 2, y, 0xFFEADE19);
        List<FormattedCharSequence> lines = font.split(Component.literal(
                "Este mod necesita una inteligencia artificial para funcionar. "
                        + "Si no se conecta, se avisará en el chat."), w);
        int ly = y + 14;
        for (FormattedCharSequence l : lines) { g.drawString(font, l, x, ly, 0xFFFFFF, false); ly += 10; }

        g.drawString(font, "API key de Groq (solo compatible con Groq):", x, y + 62, 0xFFFFFF, false);
        g.drawString(font, "TTS (opcional): ID de voz (solo FishAudio):", x, y + 108, 0xFFFFFF, false);
        super.render(g, mx, my, pt);
    }

    @Override public boolean isPauseScreen() { return false; }
}
