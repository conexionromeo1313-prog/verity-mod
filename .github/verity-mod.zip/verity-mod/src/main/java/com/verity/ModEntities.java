package com.verity;

import com.verity.entity.VerityBoxEntity;
import com.verity.entity.VerityEntity;
import com.verity.entity.VerityMonsterEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod.EventBusSubscriber(modid = VerityMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, VerityMod.MODID);

    public static final RegistryObject<EntityType<VerityBoxEntity>> VERITY_BOX = ENTITIES.register("verity_box",
            () -> EntityType.Builder.<VerityBoxEntity>of(VerityBoxEntity::new, MobCategory.MISC)
                    .sized(1.0F, 0.9F).clientTrackingRange(10).updateInterval(20).fireImmune()
                    .build("verity_box"));

    public static final RegistryObject<EntityType<VerityEntity>> VERITY = ENTITIES.register("verity",
            () -> EntityType.Builder.<VerityEntity>of(VerityEntity::new, MobCategory.CREATURE)
                    .sized(0.9F, 0.9F).clientTrackingRange(10).build("verity"));

    public static final RegistryObject<EntityType<VerityMonsterEntity>> VERITY_MONSTER = ENTITIES.register("verity_monster",
            () -> EntityType.Builder.<VerityMonsterEntity>of(VerityMonsterEntity::new, MobCategory.MONSTER)
                    .sized(0.9F, 3.0F).clientTrackingRange(16).fireImmune()
                    .build("verity_monster"));

    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent e) {
        e.put(VERITY.get(), VerityEntity.createAttributes().build());
        e.put(VERITY_MONSTER.get(), VerityMonsterEntity.createAttributes().build());
    }
}
