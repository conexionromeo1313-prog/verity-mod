package com.verity;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, VerityMod.MODID);

    public static final RegistryObject<SoundEvent> BOX_HIT = reg("box_hit");
    public static final RegistryObject<SoundEvent> IMPACT_0 = reg("impact_0");
    public static final RegistryObject<SoundEvent> IMPACT_1 = reg("impact_1");
    public static final RegistryObject<SoundEvent> IMPACT_2 = reg("impact_2");

    /** impact_0 for the first bounce, impact_1 for the second, impact_2 for every bounce after that. */
    public static SoundEvent impact(int bounceIndex) {
        return switch (Math.min(bounceIndex, 2)) {
            case 0 -> IMPACT_0.get();
            case 1 -> IMPACT_1.get();
            default -> IMPACT_2.get();
        };
    }

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(VerityMod.MODID, name)));
    }
}
