package com.verity.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.verity.VerityMod;
import com.verity.entity.VerityEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** Verity is a sphere. The face texture is projected onto the front; the back is plain yellow. */
public class VerityRenderer extends EntityRenderer<VerityEntity> {
    private static final ResourceLocation HAPPY = tex("happy");
    private static final ResourceLocation TALKING = tex("happy_talking");
    private static final ResourceLocation SERIOUS = tex("neutral");
    private static final ResourceLocation HURT = tex("hurt");
    private static final ResourceLocation CREEPY = tex("creepy");

    private static final float RADIUS = 0.45F;
    private static final int STACKS = 18, SLICES = 32;
    private static final float FACE_SCALE = 0.7F;   // how much of the texture the sphere covers

    // unit-sphere vertices and uv, built once
    private static final float[][] POS = new float[(STACKS + 1) * (SLICES + 1)][3];
    private static final float[][] UV = new float[(STACKS + 1) * (SLICES + 1)][2];

    static {
        for (int i = 0; i <= STACKS; i++) {
            double theta = Math.PI * i / STACKS;
            for (int j = 0; j <= SLICES; j++) {
                double phi = 2 * Math.PI * j / SLICES;
                float x = (float) (Math.sin(theta) * Math.cos(phi));
                float y = (float) Math.cos(theta);
                float z = (float) (Math.sin(theta) * Math.sin(phi));
                int k = i * (SLICES + 1) + j;
                POS[k][0] = x; POS[k][1] = y; POS[k][2] = z;
                if (z <= 0) {   // front hemisphere (-Z): planar projection of the face
                    UV[k][0] = 0.5F - x * 0.5F * FACE_SCALE;
                    UV[k][1] = 0.5F - y * 0.5F * FACE_SCALE;
                } else {        // back: the yellow corner of the texture
                    UV[k][0] = 0.02F;
                    UV[k][1] = 0.02F;
                }
            }
        }
    }

    public VerityRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.45F;
    }

    private static ResourceLocation tex(String n) {
        return new ResourceLocation(VerityMod.MODID, "textures/entity/verity/" + n + ".png");
    }

    @Override
    public ResourceLocation getTextureLocation(VerityEntity e) {
        return switch (e.getFace()) {
            case TALKING -> TALKING;
            case SERIOUS -> SERIOUS;
            case HURT -> HURT;
            case CREEPY -> CREEPY;
            default -> HAPPY;
        };
    }

    @Override
    public void render(VerityEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        ps.pushPose();

        float bodyYaw = Mth.rotLerp(pt, e.yBodyRotO, e.yBodyRot);
        ps.mulPose(Axis.YP.rotationDegrees(180.0F - bodyYaw));

        // squash & stretch: talking stretches her upwards again and again, falling stretches her too
        float sy = 1.0F;
        if (e.clientTalkTicks > 0) {
            sy += 0.28F * Mth.abs(Mth.sin((e.tickCount + pt) * 0.4F));
        }
        sy += (float) Mth.clamp(Math.abs(e.getDeltaMovement().y) * 0.3, 0.0, 0.3);
        float sxz = 1.0F / Mth.sqrt(sy);
        ps.scale(sxz, sy, sxz);
        ps.translate(0.0, RADIUS, 0.0);

        // rolling: she rocks forward/back while she moves
        float amp = Mth.lerp(pt, e.rockAmpO, e.rockAmp);
        float rock = 16.0F * amp * Mth.sin(Mth.lerp(pt, e.rollO, e.roll) * 1.6F);
        ps.mulPose(Axis.XP.rotationDegrees(rock));

        VertexConsumer vc = buf.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(e)));
        drawSphere(vc, ps.last().pose(), ps.last().normal(), light);

        ps.popPose();
        super.render(e, yaw, pt, ps, buf, light);
    }

    private static void drawSphere(VertexConsumer vc, Matrix4f pose, Matrix3f normal, int light) {
        for (int i = 0; i < STACKS; i++) {
            for (int j = 0; j < SLICES; j++) {
                int a = i * (SLICES + 1) + j;
                int b = a + 1;
                int c = a + SLICES + 2;
                int d = a + SLICES + 1;
                vertex(vc, pose, normal, light, a);
                vertex(vc, pose, normal, light, d);
                vertex(vc, pose, normal, light, c);
                vertex(vc, pose, normal, light, b);
            }
        }
    }

    private static void vertex(VertexConsumer vc, Matrix4f pose, Matrix3f normal, int light, int k) {
        float[] p = POS[k];
        vc.vertex(pose, p[0] * RADIUS, p[1] * RADIUS, p[2] * RADIUS)
                .color(255, 255, 255, 255)
                .uv(UV[k][0], UV[k][1])
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light)
                .normal(normal, p[0], p[1], p[2])
                .endVertex();
    }
}
