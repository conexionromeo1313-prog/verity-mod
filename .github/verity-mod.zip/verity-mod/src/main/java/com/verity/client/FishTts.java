package com.verity.client;

import com.google.gson.JsonObject;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineEvent;
import java.io.ByteArrayInputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.function.Consumer;
import java.util.function.LongConsumer;

/** Text-to-speech through Fish Audio. Runs entirely on the client. */
public class FishTts {
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();

    /**
     * @param onStart called with the audio length in milliseconds when playback begins
     * @param onError called with the HTTP status (0 = other error)
     * @param volume  0..1 linear
     */
    public static void speak(String text, String apiKey, String voiceId, float volume,
                             LongConsumer onStart, Consumer<Integer> onError) {
        JsonObject body = new JsonObject();
        body.addProperty("text", text);
        body.addProperty("reference_id", voiceId);
        body.addProperty("format", "wav");

        HttpRequest req = HttpRequest.newBuilder(URI.create("https://api.fish.audio/v1/tts"))
                .timeout(Duration.ofSeconds(40))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                .build();

        HTTP.sendAsync(req, HttpResponse.BodyHandlers.ofByteArray()).thenAccept(resp -> {
            if (resp.statusCode() / 100 != 2) { onError.accept(resp.statusCode()); return; }
            try {
                play(resp.body(), volume, onStart);
            } catch (Exception e) {
                onError.accept(0);
            }
        }).exceptionally(t -> { onError.accept(0); return null; });
    }

    private static void play(byte[] wav, float volume, LongConsumer onStart) throws Exception {
        AudioInputStream ais = AudioSystem.getAudioInputStream(new ByteArrayInputStream(wav));
        Clip clip = AudioSystem.getClip();
        clip.open(ais);
        if (clip.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
            FloatControl gain = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
            float db = (float) (20.0 * Math.log10(Math.max(volume, 0.0001f)));
            gain.setValue(Math.max(gain.getMinimum(), Math.min(gain.getMaximum(), db)));
        }
        clip.addLineListener(ev -> { if (ev.getType() == LineEvent.Type.STOP) clip.close(); });
        onStart.accept(clip.getMicrosecondLength() / 1000L);
        clip.start();
    }
}
