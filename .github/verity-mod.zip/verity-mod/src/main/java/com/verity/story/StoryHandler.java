package com.verity.story;

import com.verity.ModEntities;
import com.verity.VerityConfig;
import com.verity.VerityMod;
import com.verity.ai.GroqClient;
import com.verity.entity.VerityBoxEntity;
import com.verity.entity.VerityEntity;
import com.verity.entity.VerityMonsterEntity;
import com.verity.network.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

@Mod.EventBusSubscriber(modid = VerityMod.MODID)
public class StoryHandler {
    private static final Pattern APOLOGY = Pattern.compile(
            "perd[oó]n|perd[oó]na|lo siento|disculp|sorry|forgive|apolog", Pattern.CASE_INSENSITIVE);

    /** Groq API keys by player (sent by the client when it joins / accepts the setup screen). */
    public static final Map<UUID, String> KEYS = new ConcurrentHashMap<>();
    private static final Map<UUID, List<GroqClient.Msg>> HISTORY = new ConcurrentHashMap<>();
    private static final Set<UUID> BUSY = ConcurrentHashMap.newKeySet();
    private static final Map<UUID, Integer> PENDING_SETUP = new ConcurrentHashMap<>();

    private static final String PROMPT_NORMAL =
            "Eres Verity, una esfera amarilla con cara feliz que vive en el mundo de Minecraft y acompaña al jugador. "
                    + "Ayúdalo con consejos de supervivencia y exploración. Responde SIEMPRE en 1 o 2 frases cortas, "
                    + "con tono amistoso, en el idioma del jugador. Nunca uses formato markdown ni emojis.";
    private static final String PROMPT_CREEPY =
            "Eres Verity, una esfera amarilla que ya no está contenta: lleva días sola y te sientes ignorada. "
                    + "Sonríes de forma perturbadora. Responde en 1 o 2 frases cortas, inquietantes y lentas, en el idioma "
                    + "del jugador, sin markdown ni emojis. Insinúa que algo viene y que quizá solo una disculpa sincera "
                    + "te calmaría, pero nunca lo digas de forma directa.";

    // ------------------------------------------------------------------ speaking

    public static void say(MinecraftServer server, VerityEntity verity, String text) {
        if (server == null) return;
        Component msg = Component.literal("<Verity> ").withStyle(ChatFormatting.YELLOW).append(Component.literal(text));
        server.getPlayerList().broadcastSystemMessage(msg, false);
        ModNetwork.CHANNEL.send(PacketDistributor.ALL.noArg(), new ModNetwork.Speak(verity.getId(), text));
    }

    private static void fail(MinecraftServer server, VerityEntity verity, int code) {
        Component msg = Component.literal("<Verity> ").withStyle(ChatFormatting.YELLOW)
                .append(Component.literal("Api connection failed. " + code).withStyle(ChatFormatting.RED));
        server.getPlayerList().broadcastSystemMessage(msg, false);
        verity.setError(200);
    }

    public static VerityEntity findVerity(ServerPlayer p) {
        List<VerityEntity> list = p.level().getEntitiesOfClass(VerityEntity.class, p.getBoundingBox().inflate(128.0));
        return list.stream().min(Comparator.comparingDouble(v -> v.distanceToSqr(p))).orElse(null);
    }

    // ------------------------------------------------------------------ AI

    public static void tip(ServerPlayer p, VerityEntity v) {
        ask(p, v, "Dame un consejo corto y útil, de una sola frase, sobre explorar o sobrevivir en este momento.", true);
    }

    public static void ask(ServerPlayer p, VerityEntity v, String userText, boolean silentFail) {
        MinecraftServer server = p.getServer();
        if (server == null) return;
        String key = KEYS.get(p.getUUID());
        if (key == null || key.isBlank()) {
            if (!silentFail) fail(server, v, 0);
            return;
        }
        if (!BUSY.add(p.getUUID())) return;   // one request at a time per player

        VerityWorldData data = VerityWorldData.get(server);
        boolean creepy = data.phase == 1 || data.phase == 2;
        List<GroqClient.Msg> hist = HISTORY.computeIfAbsent(p.getUUID(), k -> new ArrayList<>());
        List<GroqClient.Msg> msgs = new ArrayList<>();
        msgs.add(new GroqClient.Msg("system", (creepy ? PROMPT_CREEPY : PROMPT_NORMAL) + "\n" + context(p)));
        synchronized (hist) { msgs.addAll(hist); }
        msgs.add(new GroqClient.Msg("user", userText));

        GroqClient.chat(key, VerityConfig.GROQ_MODEL.get(), msgs).thenAccept(res -> server.execute(() -> {
            BUSY.remove(p.getUUID());
            if (!v.isAlive()) return;
            if (res.ok()) {
                synchronized (hist) {
                    hist.add(new GroqClient.Msg("user", userText));
                    hist.add(new GroqClient.Msg("assistant", res.text()));
                    while (hist.size() > 12) hist.remove(0);
                }
                say(server, v, res.text());
            } else {
                logFail(res);
                if (!silentFail) fail(server, v, res.code());
            }
        }));
    }

    static void logFail(GroqClient.Result res) {
        org.slf4j.LoggerFactory.getLogger("verity").warn("Groq request failed ({}): {}", res.code(), res.text());
    }

    private static String context(ServerPlayer p) {
        String biome = p.level().getBiome(p.blockPosition()).unwrapKey().map(k -> k.location().getPath()).orElse("?");
        return "Contexto del jugador: dimensión=" + p.level().dimension().location()
                + ", bioma=" + biome
                + ", " + (p.level().isDay() ? "es de día" : "es de noche")
                + ", vida=" + (int) p.getHealth() + "/20"
                + ", comida=" + p.getFoodData().getFoodLevel() + "/20"
                + ", en la mano=" + p.getMainHandItem().getHoverName().getString();
    }

    /** Called when a player pressed "Aceptar" (test=true) or joined with saved keys (test=false). */
    public static void onSetup(ServerPlayer p, String groqKey, boolean test) {
        if (groqKey == null || groqKey.isBlank()) {
            KEYS.remove(p.getUUID());
        } else {
            KEYS.put(p.getUUID(), groqKey.trim());
        }
        if (!test) return;
        MinecraftServer server = p.getServer();
        VerityEntity v = findVerity(p);
        if (groqKey == null || groqKey.isBlank()) {
            if (v != null) fail(server, v, 0);
            else p.sendSystemMessage(Component.literal("Api connection failed. 0").withStyle(ChatFormatting.RED));
            return;
        }
        GroqClient.ping(groqKey.trim()).thenAccept(res -> server.execute(() -> {
            if (res.ok()) {
                p.sendSystemMessage(Component.literal("[Verity] Conectada a la IA correctamente.")
                        .withStyle(ChatFormatting.GREEN));
            } else {
                logFail(res);
                VerityEntity near = findVerity(p);
                if (near != null) fail(server, near, res.code());
                else p.sendSystemMessage(Component.literal("Api connection failed. " + res.code())
                        .withStyle(ChatFormatting.RED));
            }
        }));
    }

    // ------------------------------------------------------------------ events

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        VerityWorldData data = VerityWorldData.get(sp.getServer());
        if (!data.introDone) {
            data.introDone = true;
            data.setDirty();
            spawnBox(sp);
            PENDING_SETUP.put(sp.getUUID(), 60);   // open the setup window after a short delay
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        UUID id = e.getEntity().getUUID();
        KEYS.remove(id); HISTORY.remove(id); BUSY.remove(id); PENDING_SETUP.remove(id);
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        MinecraftServer server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;

        if (!PENDING_SETUP.isEmpty()) {
            for (UUID id : new ArrayList<>(PENDING_SETUP.keySet())) {
                int left = PENDING_SETUP.get(id) - 1;
                if (left > 0) { PENDING_SETUP.put(id, left); continue; }
                PENDING_SETUP.remove(id);
                ServerPlayer sp = server.getPlayerList().getPlayer(id);
                if (sp != null) ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> sp), new ModNetwork.OpenSetup());
            }
        }

        if (server.getTickCount() % 20 != 0 || !VerityConfig.HORROR_ENABLED.get()) return;
        VerityWorldData d = VerityWorldData.get(server);
        ServerLevel ow = server.overworld();
        long day = ow.getDayTime();

        if (d.phase == 0 && d.bornDay >= 0 && day - d.bornDay >= VerityConfig.DAYS_UNTIL_CREEPY.get() * 24000L) {
            d.phase = 1;
            d.warnTime = day;
            d.warningSpoken = false;
            d.setDirty();
        }
        if (d.phase == 1 && day - d.warnTime >= VerityConfig.DAYS_UNTIL_MONSTER.get() * 24000L) {
            long t = day % 24000L;
            if (t >= 13000L && t <= 22500L) trySpawnMonster(server, d);
        }
    }

    /** Spawns the monster 100-130 blocks away from a random overworld player. */
    public static boolean trySpawnMonster(MinecraftServer server, VerityWorldData d) {
        ServerLevel ow = server.overworld();
        List<ServerPlayer> players = ow.players();
        if (players.isEmpty()) return false;
        ServerPlayer target = players.get(ow.random.nextInt(players.size()));
        return spawnMonsterAround(ow, target, 100, 130, d);
    }

    public static boolean spawnMonsterAround(ServerLevel level, ServerPlayer target, int minDist, int maxDist, VerityWorldData d) {
        for (int attempt = 0; attempt < 8; attempt++) {
            double ang = level.random.nextDouble() * Math.PI * 2;
            double dist = minDist + level.random.nextDouble() * (maxDist - minDist);
            int x = (int) (target.getX() + Math.cos(ang) * dist);
            int z = (int) (target.getZ() + Math.sin(ang) * dist);
            if (!level.hasChunk(x >> 4, z >> 4)) continue;
            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            if (y <= level.getMinBuildHeight()) continue;
            if (!level.getFluidState(new BlockPos(x, y - 1, z)).isEmpty()) continue;
            VerityMonsterEntity m = ModEntities.VERITY_MONSTER.get().create(level);
            if (m == null) return false;
            m.moveTo(x + 0.5, y, z + 0.5, level.random.nextFloat() * 360F, 0);
            m.setPersistenceRequired();
            level.addFreshEntity(m);
            d.phase = 2;
            d.monsterId = m.getUUID();
            d.setDirty();
            return true;
        }
        return false;
    }

    @SubscribeEvent
    public static void onChat(ServerChatEvent e) {
        ServerPlayer p = e.getPlayer();
        VerityEntity v = findVerity(p);
        if (v == null) return;
        MinecraftServer server = p.getServer();
        String text = e.getRawText();
        VerityWorldData d = VerityWorldData.get(server);

        if ((d.phase == 1 || d.phase == 2) && APOLOGY.matcher(text).find()) {
            server.execute(() -> forgive(server, v, d));
            return;
        }
        server.execute(() -> ask(p, v, text, false));
    }

    private static void forgive(MinecraftServer server, VerityEntity v, VerityWorldData d) {
        d.phase = 3;
        d.monsterId = null;
        d.setDirty();
        List<Entity> monsters = new ArrayList<>();
        for (ServerLevel l : server.getAllLevels())
            for (Entity en : l.getAllEntities())
                if (en instanceof VerityMonsterEntity) monsters.add(en);
        monsters.forEach(Entity::discard);
        say(server, v, "...Está bien. Te perdono. Ya no estoy enojada. No me vuelvas a dejar sola.");
    }

    public static void spawnBox(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        Vec3 look = p.getLookAngle();
        double x = p.getX() + look.x * 3.0;
        double z = p.getZ() + look.z * 3.0;
        BlockPos top = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, BlockPos.containing(x, 0, z));
        double y = Math.abs(top.getY() - p.getY()) > 6 ? p.getY() : top.getY();
        VerityBoxEntity box = ModEntities.VERITY_BOX.get().create(level);
        if (box == null) return;
        box.moveTo(x, y, z, p.getYRot() + 180F, 0);
        level.addFreshEntity(box);
    }
}
