package com.verity.story;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.UUID;

/**
 * Per-world story state.
 * phase: 0 = normal, 1 = Verity stopped smiling (warning given), 2 = monster released, 3 = forgiven (nightmare over)
 */
public class VerityWorldData extends SavedData {
    public boolean introDone = false;
    public long bornDay = -1;          // overworld day time when Verity came out of the box
    public int phase = 0;
    public long warnTime = 0;          // day time when the smile changed
    public boolean warningSpoken = false;
    public UUID monsterId = null;

    public static VerityWorldData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(VerityWorldData::load, VerityWorldData::new, "verity_story");
    }

    public static VerityWorldData load(CompoundTag tag) {
        VerityWorldData d = new VerityWorldData();
        d.introDone = tag.getBoolean("introDone");
        d.bornDay = tag.contains("bornDay") ? tag.getLong("bornDay") : -1;
        d.phase = tag.getInt("phase");
        d.warnTime = tag.getLong("warnTime");
        d.warningSpoken = tag.getBoolean("warningSpoken");
        if (tag.hasUUID("monsterId")) d.monsterId = tag.getUUID("monsterId");
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("introDone", introDone);
        tag.putLong("bornDay", bornDay);
        tag.putInt("phase", phase);
        tag.putLong("warnTime", warnTime);
        tag.putBoolean("warningSpoken", warningSpoken);
        if (monsterId != null) tag.putUUID("monsterId", monsterId);
        return tag;
    }
}
