package com.verity.client;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import net.minecraftforge.fml.loading.FMLPaths;

import java.nio.file.Files;
import java.nio.file.Path;

/** Keys live only on the player's machine: config/verity-client.json */
public class ClientConfig {
    public static String groqKey = "";
    public static String fishKey = "";
    public static String voiceId = "";

    private static Path file() { return FMLPaths.CONFIGDIR.get().resolve("verity-client.json"); }

    public static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            JsonObject o = new Gson().fromJson(Files.readString(f), JsonObject.class);
            groqKey = str(o, "groqKey");
            fishKey = str(o, "fishKey");
            voiceId = str(o, "voiceId");
        } catch (Exception ignored) { }
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("groqKey", groqKey);
            o.addProperty("fishKey", fishKey);
            o.addProperty("voiceId", voiceId);
            Files.writeString(file(), new Gson().toJson(o));
        } catch (Exception ignored) { }
    }

    public static boolean hasTts() { return !voiceId.isBlank() && !fishKey.isBlank(); }

    private static String str(JsonObject o, String k) { return o.has(k) ? o.get(k).getAsString() : ""; }
}
