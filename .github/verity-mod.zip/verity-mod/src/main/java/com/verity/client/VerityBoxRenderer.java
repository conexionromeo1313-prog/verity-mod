package com.verity.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.verity.VerityMod;
import com.verity.entity.VerityBoxEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class VerityBoxRenderer extends EntityRenderer<VerityBoxEntity> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(VerityMod.MODID, "textures/entity/verity_box.png");
    private final VerityBoxModel model;

    public VerityBoxRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.model = new VerityBoxModel(ctx.bakeLayer(VerityBoxModel.LAYER));
        this.shadowRadius = 0.5F;
    }

    @Override
    public ResourceLocation getTextureLocation(VerityBoxEntity e) { return TEXTURE; }

    @Override
    public void render(VerityBoxEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        float time = e.getTime() + pt;
        int open = e.getOpenStart();
        float ot = open >= 0 ? (e.getTime() - open) + pt : -1.0F;

        // "punches" from the inside: grows, then shrinks back
        float period = ot >= 0 ? 5.0F : VerityBoxEntity.PERIOD;
        float p = time % period;
        float punch;
        if (p < 3.0F) punch = p / 3.0F;
        else if (p < 9.0F) punch = 1.0F - (p - 3.0F) / 6.0F;
        else punch = 0.0F;
        punch = Math.max(punch, 0.0F);
        float scale = 1.0F + 0.22F * punch;

        float rise = 0.0F;
        float lid = 0.0F;
        if (ot >= 0) {
            float k = Mth.clamp(ot / VerityBoxEntity.RISE_TICKS, 0.0F, 1.0F);
            rise = 0.7F * (1.0F - (1.0F - k) * (1.0F - k));
            float l = Mth.clamp((ot - VerityBoxEntity.LID_START) / (VerityBoxEntity.LID_END - VerityBoxEntity.LID_START), 0.0F, 1.0F);
            lid = l * 1.9F;   // ~110 degrees
        }

        ps.pushPose();
        ps.translate(Mth.sin(time * 7.0F) * 0.02F * (punch + (ot >= 0 ? 1 : 0)), rise, 0.0);
        ps.scale(scale, scale, scale);
        ps.mulPose(Axis.YP.rotationDegrees(180.0F - e.getYRot()));
        ps.scale(-1.0F, -1.0F, 1.0F);
        ps.translate(0.0, -1.501, 0.0);

        model.setLidAngle(lid);
        VertexConsumer vc = buf.getBuffer(model.renderType(TEXTURE));
        model.renderToBuffer(ps, vc, light, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);
        ps.popPose();

        super.render(e, yaw, pt, ps, buf, light);
    }
}
