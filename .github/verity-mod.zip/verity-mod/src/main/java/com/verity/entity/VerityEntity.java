package com.verity.entity;

import com.verity.ModSounds;
import com.verity.VerityConfig;
import com.verity.story.StoryHandler;
import com.verity.story.VerityWorldData;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import java.util.EnumSet;

public class VerityEntity extends PathfinderMob {
    private static final EntityDataAccessor<Boolean> DATA_BOUNCING =
            SynchedEntityData.defineId(VerityEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_ERROR =
            SynchedEntityData.defineId(VerityEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_CREEPY =
            SynchedEntityData.defineId(VerityEntity.class, EntityDataSerializers.BOOLEAN);

    public enum Face { HAPPY, TALKING, SERIOUS, HURT, CREEPY }

    // server state
    private int bounceCount = 0;
    private int errorTicks = 0;
    private int tipTimer = 0;
    private boolean greeted = false;

    // client-only animation state
    public int clientTalkTicks = 0;
    public float roll, rollO, rockAmp, rockAmpO;

    public VerityEntity(EntityType<? extends VerityEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.22)
                .add(Attributes.FOLLOW_RANGE, 48.0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new FollowPlayerGoal());
        goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.8));
        goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(4, new RandomLookAroundGoal(this));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(DATA_BOUNCING, false);
        entityData.define(DATA_ERROR, false);
        entityData.define(DATA_CREEPY, false);
    }

    // ------------------------------------------------------------------ state

    public boolean isBouncing() { return entityData.get(DATA_BOUNCING); }
    private void setBouncing(boolean b) { entityData.set(DATA_BOUNCING, b); }
    public boolean isError() { return entityData.get(DATA_ERROR); }
    public boolean isCreepy() { return entityData.get(DATA_CREEPY); }

    /** Called when the AI could not be reached: serious face for a while. */
    public void setError(int ticks) { this.errorTicks = ticks; entityData.set(DATA_ERROR, true); }

    /** Client side: stretch-talk animation for this many ticks. */
    public void talkFor(int ticks) { this.clientTalkTicks = Math.max(this.clientTalkTicks, ticks); }

    /** Thrown out of the box. */
    public void launch(double vx, double vy, double vz) {
        setBouncing(true);
        bounceCount = 0;
        setDeltaMovement(vx, vy, vz);
        hasImpulse = true;
    }

    public Face getFace() {
        if (isCreepy()) return Face.CREEPY;
        if (isBouncing() || (!onGround() && getDeltaMovement().y < -0.3)) return Face.HURT;
        if (isError()) return Face.SERIOUS;
        if (clientTalkTicks > 0) return ((tickCount / 4) % 2 == 0) ? Face.TALKING : Face.HAPPY;
        return Face.HAPPY;
    }

    // ------------------------------------------------------------------ tick

    @Override
    public void tick() {
        double vyBefore = getDeltaMovement().y;   // velocity that this tick's move() will use
        super.tick();

        if (level().isClientSide) {
            if (clientTalkTicks > 0) clientTalkTicks--;
            double dx = getX() - xo, dz = getZ() - zo;
            float speed = (float) Math.sqrt(dx * dx + dz * dz);
            rollO = roll;
            rockAmpO = rockAmp;
            roll += speed / 0.45F;
            rockAmp += (Math.min(1.0F, speed * 8.0F) - rockAmp) * 0.3F;
            return;
        }

        if (isBouncing()) {
            getNavigation().stop();
            if (onGround() && vyBefore < -0.12) {
                double next = -vyBefore * 0.62;
                playImpact();
                if (next > 0.12) {
                    setDeltaMovement(getDeltaMovement().x * 0.9, next, getDeltaMovement().z * 0.9);
                    hasImpulse = true;
                } else {
                    setBouncing(false);
                    setDeltaMovement(getDeltaMovement().multiply(0.4, 0, 0.4));
                    onSettled();
                }
            }
        }

        if (errorTicks > 0 && --errorTicks == 0) entityData.set(DATA_ERROR, false);

        if (tickCount % 20 == 0) serverSecond();
    }

    private void playImpact() {
        level().playSound(null, getX(), getY(), getZ(), ModSounds.impact(bounceCount), SoundSource.NEUTRAL,
                1.0F, 0.95F + random.nextFloat() * 0.1F);
        bounceCount++;
    }

    private void onSettled() {
        if (greeted) return;
        greeted = true;
        StoryHandler.say(level().getServer(), this,
                "¡Hola! Soy Verity. Escríbeme en el chat cuando quieras y te ayudaré a explorar este mundo.");
    }

    private void serverSecond() {
        var server = level().getServer();
        if (server == null) return;
        VerityWorldData data = VerityWorldData.get(server);
        boolean creepy = VerityConfig.HORROR_ENABLED.get() && (data.phase == 1 || data.phase == 2);
        if (creepy != isCreepy()) entityData.set(DATA_CREEPY, creepy);

        if (data.phase == 1 && !data.warningSpoken) {
            data.warningSpoken = true;
            data.setDirty();
            StoryHandler.say(server, this,
                    "Algo vendrá aquí en tres días... Si no proteges tu base, un monstruo extraño te encontrará. "
                            + "Estará muy lejos, pero caminará de noche. Y quizá solo yo pueda detenerlo.");
        }

        int interval = VerityConfig.TIP_SECONDS.get();
        if (interval > 0 && !creepy && !isBouncing() && ++tipTimer >= interval) {
            tipTimer = 0;
            Player p = level().getNearestPlayer(this, 32.0);
            if (p instanceof ServerPlayer sp) StoryHandler.tip(sp, this);
        }
    }

    // ------------------------------------------------------------------ misc

    @Override
    public boolean causeFallDamage(float dist, float mult, DamageSource src) { return false; }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.hurt(source, amount);
        return false;
    }

    @Override public boolean removeWhenFarAway(double d) { return false; }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Greeted", greeted);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        greeted = tag.getBoolean("Greeted");
    }

    /** Walks back towards the nearest player if she wandered too far away. */
    private class FollowPlayerGoal extends Goal {
        private Player target;
        FollowPlayerGoal() { setFlags(EnumSet.of(Flag.MOVE)); }

        @Override public boolean canUse() {
            if (isBouncing() || isCreepy()) return false;
            target = level().getNearestPlayer(VerityEntity.this, 64.0);
            return target != null && distanceToSqr(target) > 12.0 * 12.0;
        }
        @Override public boolean canContinueToUse() {
            return !isBouncing() && target != null && target.isAlive() && distanceToSqr(target) > 5.0 * 5.0
                    && !getNavigation().isDone();
        }
        @Override public void start() { getNavigation().moveTo(target, 1.0); }
        @Override public void stop() { getNavigation().stop(); target = null; }
    }
}
