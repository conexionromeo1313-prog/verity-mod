package com.verity;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod.EventBusSubscriber(modid = VerityMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, VerityMod.MODID);

    public static final RegistryObject<Item> VERITY_EGG = ITEMS.register("verity_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.VERITY, 0xEADE19, 0x000000, new Item.Properties()));
    public static final RegistryObject<Item> MONSTER_EGG = ITEMS.register("verity_monster_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.VERITY_MONSTER, 0x2B2B0A, 0xEADE19, new Item.Properties()));

    @SubscribeEvent
    public static void tabs(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            e.accept(VERITY_EGG);
            e.accept(MONSTER_EGG);
        }
    }
}
