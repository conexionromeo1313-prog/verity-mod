package com.verity.command;

import com.mojang.brigadier.CommandDispatcher;
import com.verity.VerityMod;
import com.verity.network.ModNetwork;
import com.verity.story.StoryHandler;
import com.verity.story.VerityWorldData;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

@Mod.EventBusSubscriber(modid = VerityMod.MODID)
public class VerityCommand {
    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        CommandDispatcher<CommandSourceStack> d = e.getDispatcher();
        d.register(Commands.literal("verity").requires(s -> s.hasPermission(2))
                .then(Commands.literal("box").executes(c -> {
                    StoryHandler.spawnBox(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("setup").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new ModNetwork.OpenSetup());
                    return 1;
                }))
                .then(Commands.literal("horror").executes(c -> {
                    VerityWorldData data = VerityWorldData.get(c.getSource().getServer());
                    data.phase = 1;
                    data.warnTime = c.getSource().getServer().overworld().getDayTime();
                    data.warningSpoken = false;
                    data.setDirty();
                    c.getSource().sendSuccess(() -> Component.literal("Verity stopped smiling."), true);
                    return 1;
                }))
                .then(Commands.literal("monster").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    VerityWorldData data = VerityWorldData.get(c.getSource().getServer());
                    boolean ok = StoryHandler.spawnMonsterAround(p.serverLevel(), p, 40, 55, data);
                    c.getSource().sendSuccess(() -> Component.literal(ok ? "Spawned." : "No valid spot, try again."), true);
                    return 1;
                }))
                .then(Commands.literal("reset").executes(c -> {
                    VerityWorldData data = VerityWorldData.get(c.getSource().getServer());
                    data.phase = 0;
                    data.warningSpoken = false;
                    data.setDirty();
                    c.getSource().sendSuccess(() -> Component.literal("Story reset to phase 0."), true);
                    return 1;
                })));
    }
}
