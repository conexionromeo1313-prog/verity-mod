package com.verity.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.verity.VerityMod;
import com.verity.entity.VerityMonsterEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Tall, thin and wrong. 48 px (3 blocks) tall. */
public class VerityMonsterModel extends EntityModel<VerityMonsterEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(VerityMod.MODID, "verity_monster"), "main");

    private final ModelPart root, head, body, rightArm, leftArm, rightLeg, leftLeg;

    public VerityMonsterModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.body = root.getChild("body");
        this.rightArm = root.getChild("right_arm");
        this.leftArm = root.getChild("left_arm");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();
        r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F), PartPose.offset(0.0F, -16.0F, 0.0F));
        r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 16)
                .addBox(-3.0F, 0.0F, -2.0F, 6.0F, 18.0F, 4.0F), PartPose.offset(0.0F, -16.0F, 0.0F));
        CubeListBuilder arm = CubeListBuilder.create().texOffs(32, 16)
                .addBox(-1.5F, 0.0F, -1.5F, 3.0F, 28.0F, 3.0F);
        r.addOrReplaceChild("right_arm", arm, PartPose.offset(-4.5F, -15.0F, 0.0F));
        r.addOrReplaceChild("left_arm", arm, PartPose.offset(4.5F, -15.0F, 0.0F));
        CubeListBuilder leg = CubeListBuilder.create().texOffs(48, 16)
                .addBox(-1.5F, 0.0F, -1.5F, 3.0F, 22.0F, 3.0F);
        r.addOrReplaceChild("right_leg", leg, PartPose.offset(-2.0F, 2.0F, 0.0F));
        r.addOrReplaceChild("left_leg", leg, PartPose.offset(2.0F, 2.0F, 0.0F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(VerityMonsterEntity e, float limbSwing, float limbSwingAmount, float age, float headYaw, float headPitch) {
        for (ModelPart p : new ModelPart[]{head, body, rightArm, leftArm, rightLeg, leftLeg}) {
            p.xRot = 0; p.yRot = 0; p.zRot = 0;
        }
        head.y = -16.0F; body.y = -16.0F;

        int state = e.getMonsterState();
        float tw = Mth.clamp(e.getTwistTicks() / (float) VerityMonsterEntity.TWIST_TICKS, 0.0F, 1.0F);

        if (state == VerityMonsterEntity.STATE_TWIST) {
            // the body twists, the head turns the wrong way, the limbs bend
            float shake = Mth.sin(age * 1.9F) * 0.06F * tw;
            body.yRot = tw * 1.3F + shake;
            body.xRot = tw * 0.5F;
            head.yRot = tw * Mth.PI + Mth.sin(age * 1.7F) * 0.25F * tw;
            head.zRot = tw * 0.9F * Mth.sin(age * 0.45F);
            head.xRot = tw * 0.4F;
            rightArm.xRot = -tw * 1.6F + Mth.sin(age * 1.3F) * 0.4F * tw;
            leftArm.xRot = -tw * 1.2F + Mth.sin(age * 1.1F + 2.0F) * 0.5F * tw;
            rightArm.zRot = -tw * 0.9F;
            leftArm.zRot = tw * 1.1F;
            rightLeg.xRot = Mth.sin(age * 1.1F) * 0.5F * tw;
            leftLeg.xRot = -Mth.sin(age * 1.4F) * 0.5F * tw;
            leftLeg.zRot = tw * 0.25F;
        } else if (state == VerityMonsterEntity.STATE_CHASE) {
            float sw = Mth.clamp(limbSwingAmount * 2.0F, 0.0F, 1.0F);
            rightLeg.xRot = Mth.cos(limbSwing * 0.9F) * 1.6F * sw;
            leftLeg.xRot = -Mth.cos(limbSwing * 0.9F) * 1.6F * sw;
            rightArm.xRot = -1.45F + Mth.sin(age * 1.8F) * 0.15F;
            leftArm.xRot = -1.45F - Mth.sin(age * 1.8F) * 0.15F;
            body.xRot = 0.35F;
            head.xRot = 0.2F;
            head.zRot = 1.2F;   // head sideways, staring
        } else {
            rightLeg.xRot = Mth.cos(limbSwing * 0.5F) * 1.0F * limbSwingAmount;
            leftLeg.xRot = -Mth.cos(limbSwing * 0.5F) * 1.0F * limbSwingAmount;
            rightArm.xRot = -Mth.cos(limbSwing * 0.5F) * 0.5F * limbSwingAmount + Mth.sin(age * 0.05F) * 0.03F;
            leftArm.xRot = Mth.cos(limbSwing * 0.5F) * 0.5F * limbSwingAmount - Mth.sin(age * 0.05F) * 0.03F;
            head.zRot = 0.2F + Mth.sin(age * 0.04F) * 0.08F;
            head.xRot = 0.15F;
        }
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, float r, float g, float b, float a) {
        root.render(ps, vc, light, overlay, r, g, b, a);
    }
}
