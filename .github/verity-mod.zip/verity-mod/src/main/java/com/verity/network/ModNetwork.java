package com.verity.network;

import com.verity.VerityMod;
import com.verity.client.ClientHooks;
import com.verity.story.StoryHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

public class ModNetwork {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(VerityMod.MODID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, OpenSetup.class, OpenSetup::encode, OpenSetup::decode, OpenSetup::handle);
        CHANNEL.registerMessage(id++, Setup.class, Setup::encode, Setup::decode, Setup::handle);
        CHANNEL.registerMessage(id++, Speak.class, Speak::encode, Speak::decode, Speak::handle);
    }

    /** server -> client: show the "warning / API key / TTS" window */
    public static class OpenSetup {
        public void encode(FriendlyByteBuf buf) { }
        public static OpenSetup decode(FriendlyByteBuf buf) { return new OpenSetup(); }
        public void handle(Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> ClientHooks::openSetup));
            ctx.get().setPacketHandled(true);
        }
    }

    /** client -> server: the Groq key (TTS data never leaves the client). */
    public static class Setup {
        public final String groqKey;
        public final boolean test;
        public Setup(String groqKey, boolean test) { this.groqKey = groqKey; this.test = test; }
        public void encode(FriendlyByteBuf buf) { buf.writeUtf(groqKey, 512); buf.writeBoolean(test); }
        public static Setup decode(FriendlyByteBuf buf) { return new Setup(buf.readUtf(512), buf.readBoolean()); }
        public void handle(Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> {
                ServerPlayer p = ctx.get().getSender();
                if (p != null) StoryHandler.onSetup(p, groqKey, test);
            });
            ctx.get().setPacketHandled(true);
        }
    }

    /** server -> client: Verity says something (animation + optional TTS on the client). */
    public static class Speak {
        public final int entityId;
        public final String text;
        public Speak(int entityId, String text) { this.entityId = entityId; this.text = text; }
        public void encode(FriendlyByteBuf buf) { buf.writeVarInt(entityId); buf.writeUtf(text, 2048); }
        public static Speak decode(FriendlyByteBuf buf) { return new Speak(buf.readVarInt(), buf.readUtf(2048)); }
        public void handle(Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() ->
                    DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.onSpeak(entityId, text)));
            ctx.get().setPacketHandled(true);
        }
    }
}
