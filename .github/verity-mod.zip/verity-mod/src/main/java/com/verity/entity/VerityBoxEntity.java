package com.verity.entity;

import com.verity.ModEntities;
import com.verity.ModSounds;
import com.verity.story.VerityWorldData;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;

/** The cardboard box: punches from the inside, and when you interact it rises, opens and blows up. */
public class VerityBoxEntity extends Entity {
    private static final EntityDataAccessor<Integer> DATA_TIME =
            SynchedEntityData.defineId(VerityBoxEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_OPEN_START =
            SynchedEntityData.defineId(VerityBoxEntity.class, EntityDataSerializers.INT);

    /** ticks between "punches" while idle */
    public static final int PERIOD = 20;
    public static final int RISE_TICKS = 20;
    public static final int LID_START = 20;
    public static final int LID_END = 30;
    public static final int EXPLODE_TICK = 36;

    public VerityBoxEntity(EntityType<? extends VerityBoxEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(DATA_TIME, 0);
        entityData.define(DATA_OPEN_START, -1);
    }

    public int getTime() { return entityData.get(DATA_TIME); }
    public int getOpenStart() { return entityData.get(DATA_OPEN_START); }

    @Override public boolean isPickable() { return !isRemoved(); }
    @Override public boolean isPushable() { return false; }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (!level().isClientSide && getOpenStart() < 0) {
            entityData.set(DATA_OPEN_START, getTime());
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;

        int t = getTime() + 1;
        entityData.set(DATA_TIME, t);
        int open = getOpenStart();

        if (open < 0) {
            if (t % PERIOD == 0) knock();
            return;
        }
        int ot = t - open;
        if (ot < LID_START && ot % 5 == 0) knock();
        if (ot >= EXPLODE_TICK) explode();
    }

    private void knock() {
        level().playSound(null, getX(), getY(), getZ(), ModSounds.BOX_HIT.get(), SoundSource.NEUTRAL,
                1.0F, 0.92F + random.nextFloat() * 0.16F);
    }

    private void explode() {
        ServerLevel sl = (ServerLevel) level();
        double x = getX(), y = getY(), z = getZ();
        sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, x, y + 1.0, z, 1, 0, 0, 0, 0);
        sl.sendParticles(ParticleTypes.POOF, x, y + 1.0, z, 40, 0.45, 0.45, 0.45, 0.06);
        sl.playSound(null, x, y, z, SoundEvents.GENERIC_EXPLODE, SoundSource.NEUTRAL, 1.2F, 1.1F);

        VerityEntity verity = ModEntities.VERITY.get().create(sl);
        if (verity != null) {
            verity.moveTo(x, y + 1.4, z, random.nextFloat() * 360F, 0);
            verity.launch((random.nextDouble() - 0.5) * 0.3, 0.95, (random.nextDouble() - 0.5) * 0.3);
            sl.addFreshEntity(verity);
            VerityWorldData data = VerityWorldData.get(sl.getServer());
            if (data.bornDay < 0) {
                data.bornDay = sl.getServer().overworld().getDayTime();
                data.setDirty();
            }
        }
        discard();
    }

    @Override protected void readAdditionalSaveData(CompoundTag tag) { }
    @Override protected void addAdditionalSaveData(CompoundTag tag) { }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
