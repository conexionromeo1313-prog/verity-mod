package com.verity.client;

import com.verity.ModEntities;
import com.verity.VerityMod;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

public class ClientEvents {
    @Mod.EventBusSubscriber(modid = VerityMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ModBus {
        @SubscribeEvent
        public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
            e.registerEntityRenderer(ModEntities.VERITY.get(), VerityRenderer::new);
            e.registerEntityRenderer(ModEntities.VERITY_BOX.get(), VerityBoxRenderer::new);
            e.registerEntityRenderer(ModEntities.VERITY_MONSTER.get(), VerityMonsterRenderer::new);
        }

        @SubscribeEvent
        public static void layers(EntityRenderersEvent.RegisterLayerDefinitions e) {
            e.registerLayerDefinition(VerityBoxModel.LAYER, VerityBoxModel::createLayer);
            e.registerLayerDefinition(VerityMonsterModel.LAYER, VerityMonsterModel::createLayer);
        }
    }

    @Mod.EventBusSubscriber(modid = VerityMod.MODID, value = Dist.CLIENT)
    public static class ForgeBus {
        private static boolean sendKey = false;

        @SubscribeEvent
        public static void login(ClientPlayerNetworkEvent.LoggingIn e) {
            ClientConfig.load();
            sendKey = true;
        }

        @SubscribeEvent
        public static void tick(TickEvent.ClientTickEvent e) {
            if (e.phase == TickEvent.Phase.END && sendKey && Minecraft.getInstance().player != null) {
                sendKey = false;
                ClientHooks.sendSavedKey();
            }
        }
    }
}
