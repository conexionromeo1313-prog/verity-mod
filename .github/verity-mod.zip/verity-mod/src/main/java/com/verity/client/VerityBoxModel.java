package com.verity.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.verity.VerityMod;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;

public class VerityBoxModel extends Model {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(VerityMod.MODID, "verity_box"), "main");

    private final ModelPart root;
    private final ModelPart lid;

    public VerityBoxModel(ModelPart root) {
        super(RenderType::entityCutoutNoCull);
        this.root = root;
        this.lid = root.getChild("lid");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();
        r.addOrReplaceChild("base", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-8.0F, -10.0F, -8.0F, 16.0F, 10.0F, 16.0F), PartPose.offset(0.0F, 24.0F, 0.0F));
        // hinge on the back edge of the box
        r.addOrReplaceChild("lid", CubeListBuilder.create().texOffs(0, 32)
                .addBox(-9.0F, -4.0F, -18.0F, 18.0F, 4.0F, 18.0F), PartPose.offset(0.0F, 14.0F, 9.0F));
        return LayerDefinition.create(mesh, 128, 64);
    }

    /** radians, 0 = closed */
    public void setLidAngle(float angle) {
        lid.xRot = -angle;
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, float r, float g, float b, float a) {
        root.render(ps, vc, light, overlay, r, g, b, a);
    }
}
