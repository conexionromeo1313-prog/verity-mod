package com.verity.ai;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/** Minimal Groq (OpenAI-compatible) client. Code 0 = no HTTP response at all (network error / no key). */
public class GroqClient {
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
    private static final String BASE = "https://api.groq.com/openai/v1";

    public record Result(boolean ok, String text, int code) { }

    public record Msg(String role, String content) { }

    public static CompletableFuture<Result> chat(String apiKey, String model, List<Msg> messages) {
        JsonObject body = new JsonObject();
        body.addProperty("model", model);
        body.addProperty("temperature", 0.8);
        body.addProperty("max_tokens", 220);
        JsonArray arr = new JsonArray();
        for (Msg m : messages) {
            JsonObject o = new JsonObject();
            o.addProperty("role", m.role());
            o.addProperty("content", m.content());
            arr.add(o);
        }
        body.add("messages", arr);

        HttpRequest req = HttpRequest.newBuilder(URI.create(BASE + "/chat/completions"))
                .timeout(Duration.ofSeconds(30))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                .build();
        return send(req, true);
    }

    /** Cheap check that the key works (lists models, uses no tokens). */
    public static CompletableFuture<Result> ping(String apiKey) {
        HttpRequest req = HttpRequest.newBuilder(URI.create(BASE + "/models"))
                .timeout(Duration.ofSeconds(15))
                .header("Authorization", "Bearer " + apiKey)
                .GET().build();
        return send(req, false);
    }

    private static CompletableFuture<Result> send(HttpRequest req, boolean parse) {
        return HTTP.sendAsync(req, HttpResponse.BodyHandlers.ofString())
                .thenApply(resp -> {
                    int code = resp.statusCode();
                    if (code / 100 != 2) return new Result(false, resp.body(), code);
                    if (!parse) return new Result(true, "", code);
                    try {
                        String text = JsonParser.parseString(resp.body()).getAsJsonObject()
                                .getAsJsonArray("choices").get(0).getAsJsonObject()
                                .getAsJsonObject("message").get("content").getAsString().trim();
                        return new Result(true, text, code);
                    } catch (Exception e) {
                        return new Result(false, "bad response: " + e, code);
                    }
                })
                .exceptionally(t -> new Result(false, String.valueOf(t), 0));
    }
}
