package com.verity.client;

import com.verity.VerityMod;
import com.verity.entity.VerityMonsterEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class VerityMonsterRenderer extends MobRenderer<VerityMonsterEntity, VerityMonsterModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(VerityMod.MODID, "textures/entity/verity_monster.png");

    public VerityMonsterRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new VerityMonsterModel(ctx.bakeLayer(VerityMonsterModel.LAYER)), 0.7F);
    }

    @Override
    public ResourceLocation getTextureLocation(VerityMonsterEntity e) { return TEXTURE; }
}
