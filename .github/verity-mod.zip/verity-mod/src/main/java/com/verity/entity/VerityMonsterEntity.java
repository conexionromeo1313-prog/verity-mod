package com.verity.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.ForgeEventFactory;

import java.util.EnumSet;

/** The thing that walks at night. Far away at first. Get too close and it starts to twist... */
public class VerityMonsterEntity extends Monster {
    public static final int STATE_WANDER = 0, STATE_TWIST = 1, STATE_CHASE = 2;
    public static final int TWIST_TICKS = 70;

    private static final EntityDataAccessor<Integer> DATA_STATE =
            SynchedEntityData.defineId(VerityMonsterEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_TWIST =
            SynchedEntityData.defineId(VerityMonsterEntity.class, EntityDataSerializers.INT);

    private int lostTargetTicks = 0;

    public VerityMonsterEntity(EntityType<? extends VerityMonsterEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 300.0)
                .add(Attributes.MOVEMENT_SPEED, 0.30)
                .add(Attributes.ATTACK_DAMAGE, 12.0)
                .add(Attributes.FOLLOW_RANGE, 64.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.25, true));
        goalSelector.addGoal(2, new StalkGoal());
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(DATA_STATE, STATE_WANDER);
        entityData.define(DATA_TWIST, 0);
    }

    public int getMonsterState() { return entityData.get(DATA_STATE); }
    public int getTwistTicks() { return entityData.get(DATA_TWIST); }
    private void setMonsterState(int s) { entityData.set(DATA_STATE, s); }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;

        switch (getMonsterState()) {
            case STATE_WANDER -> {
                Player p = level().getNearestPlayer(this, 20.0);
                if (p != null && !p.isSpectator()) {
                    setMonsterState(STATE_TWIST);
                    entityData.set(DATA_TWIST, 0);
                    getNavigation().stop();
                    setTarget(null);
                }
            }
            case STATE_TWIST -> {
                getNavigation().stop();
                setDeltaMovement(0, getDeltaMovement().y, 0);
                int t = getTwistTicks() + 1;
                entityData.set(DATA_TWIST, t);
                Player p = level().getNearestPlayer(this, 48.0);
                if (p != null) getLookControl().setLookAt(p, 30, 30);
                if (t % 5 == 0) {
                    level().playSound(null, getX(), getY(), getZ(), SoundEvents.BONE_BLOCK_BREAK,
                            SoundSource.HOSTILE, 2.0F, 0.4F + random.nextFloat() * 0.4F);
                }
                if (t % 9 == 3) {
                    level().playSound(null, getX(), getY(), getZ(), SoundEvents.SKELETON_HURT,
                            SoundSource.HOSTILE, 1.6F, 0.3F + random.nextFloat() * 0.2F);
                }
                if (t >= TWIST_TICKS) {
                    setMonsterState(STATE_CHASE);
                    if (p != null) setTarget(p);
                    level().playSound(null, getX(), getY(), getZ(), SoundEvents.WITHER_SPAWN,
                            SoundSource.HOSTILE, 0.6F, 0.5F);
                }
            }
            case STATE_CHASE -> {
                if (getTarget() == null || !getTarget().isAlive()) {
                    Player p = level().getNearestPlayer(this, 48.0);
                    setTarget(p != null && !p.isSpectator() ? p : null);
                }
                lostTargetTicks = getTarget() == null ? lostTargetTicks + 1 : 0;
                if (lostTargetTicks > 200) {
                    setMonsterState(STATE_WANDER);
                    entityData.set(DATA_TWIST, 0);
                    lostTargetTicks = 0;
                }
                if (tickCount % 2 == 0) breakBlocksAround();
            }
        }
    }

    /** Destroys everything that is in its way (respects the mobGriefing gamerule). */
    private void breakBlocksAround() {
        if (!ForgeEventFactory.getMobGriefingEvent(level(), this)) return;
        AABB bb = getBoundingBox().inflate(0.8, 0.0, 0.8);
        Vec3 look = getLookAngle();
        bb = bb.move(look.x * 0.7, 0, look.z * 0.7);
        BlockPos min = BlockPos.containing(bb.minX, bb.minY, bb.minZ);
        BlockPos max = BlockPos.containing(bb.maxX - 1.0E-4, bb.maxY - 1.0E-4, bb.maxZ - 1.0E-4);
        int budget = 24;
        for (BlockPos pos : BlockPos.betweenClosed(min, max)) {
            if (budget <= 0) return;
            BlockState state = level().getBlockState(pos);
            if (state.isAir() || state.getBlock() instanceof LiquidBlock) continue;
            if (state.getDestroySpeed(level(), pos) < 0 || state.is(BlockTags.WITHER_IMMUNE)) continue;
            level().destroyBlock(pos.immutable(), false, this);
            budget--;
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.hurt(source, amount);
        return false;
    }

    @Override public boolean fireImmune() { return true; }
    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override protected boolean shouldDespawnInPeaceful() { return false; }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("MonsterState", getMonsterState());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setMonsterState(Mth.clamp(tag.getInt("MonsterState"), 0, 2));
    }

    /** Slowly drifts towards the nearest player (very far away at first). */
    private class StalkGoal extends Goal {
        private int cooldown = 0;
        StalkGoal() { setFlags(EnumSet.of(Flag.MOVE)); }

        @Override public boolean canUse() {
            if (getMonsterState() != STATE_WANDER) return false;
            if (cooldown-- > 0) return false;
            cooldown = 20;
            return level().getNearestPlayer(VerityMonsterEntity.this, 200.0) != null;
        }
        @Override public boolean canContinueToUse() {
            return getMonsterState() == STATE_WANDER && !getNavigation().isDone();
        }
        @Override public void start() {
            Player p = level().getNearestPlayer(VerityMonsterEntity.this, 200.0);
            if (p == null) return;
            Vec3 pos = DefaultRandomPos.getPosTowards(VerityMonsterEntity.this, 16, 7, p.position(), Math.PI / 2);
            if (pos != null) getNavigation().moveTo(pos.x, pos.y, pos.z, 0.6);
        }
    }
}
