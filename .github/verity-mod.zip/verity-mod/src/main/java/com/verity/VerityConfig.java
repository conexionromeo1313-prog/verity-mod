package com.verity;

import net.minecraftforge.common.ForgeConfigSpec;

public class VerityConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.ConfigValue<String> GROQ_MODEL;
    public static final ForgeConfigSpec.IntValue TIP_SECONDS;
    public static final ForgeConfigSpec.BooleanValue HORROR_ENABLED;
    public static final ForgeConfigSpec.IntValue DAYS_UNTIL_CREEPY;
    public static final ForgeConfigSpec.IntValue DAYS_UNTIL_MONSTER;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        GROQ_MODEL = b.comment("Groq chat model used by Verity (change it if Groq retires this one)")
                .define("groqModel", "llama-3.3-70b-versatile");
        TIP_SECONDS = b.comment("Seconds between the tips Verity gives you on her own (0 = never)")
                .defineInRange("tipSeconds", 300, 0, 86400);
        HORROR_ENABLED = b.comment("Enable the 'Verity stops smiling' storyline")
                .define("horrorEnabled", true);
        DAYS_UNTIL_CREEPY = b.comment("Minecraft days after Verity appears until her smile changes")
                .defineInRange("daysUntilCreepy", 2, 0, 1000);
        DAYS_UNTIL_MONSTER = b.comment("Minecraft days after the warning until the monster starts walking")
                .defineInRange("daysUntilMonster", 3, 0, 1000);
        SPEC = b.build();
    }
}
