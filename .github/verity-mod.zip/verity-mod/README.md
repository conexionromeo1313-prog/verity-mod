# Verity (Forge 1.20.1, Java Edition)

## Compilar
1. Copia en esta carpeta el `gradlew`, `gradlew.bat` y la carpeta `gradle/` del MDK oficial de Forge 1.20.1
   (https://files.minecraftforge.net -> 1.20.1 -> Mdk). Necesitas JDK 17.
2. `./gradlew build` -> el .jar queda en `build/libs/`. Para probar: `./gradlew runClient`.

## Uso
- Al entrar por primera vez a un mundo aparece la caja y se abre la ventana de configuración
  (API key de Groq, ID de voz y API key de Fish Audio). Se guarda en `config/verity-client.json`.
- Click derecho a la caja -> se eleva, abre la tapa, explota y sale Verity rebotando.
- Escríbele por el chat normal. Si la IA falla responde `Api connection failed. <código>`.
- Después de 2 días de Minecraft pone la sonrisa perturbadora; 3 días después suelta al monstruo (de noche, lejos).
  Para detenerlo escribe en el chat una disculpa ("perdón", "lo siento", "sorry"...).

## Comandos (permiso 2)
`/verity box` · `/verity setup` · `/verity horror` · `/verity monster` · `/verity reset`

## Config (`config/verity-common.toml`)
`groqModel`, `tipSeconds`, `horrorEnabled`, `daysUntilCreepy`, `daysUntilMonster`.

## Compilar sin instalar nada (GitHub)
1. Crea un repositorio en github.com y sube todo el contenido de esta carpeta (incluida `.github`).
2. Pestaña **Actions** -> workflow "Build Verity" -> espera a que termine (verde).
3. Abre la ejecución y descarga el artefacto **verity-jar** (es un zip con el `.jar` dentro).
4. Pon ese `.jar` en la carpeta `mods` (Forge 1.20.1).
